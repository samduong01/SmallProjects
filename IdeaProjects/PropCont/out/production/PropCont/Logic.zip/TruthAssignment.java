//stub class
public class TruthAssignment {

}
