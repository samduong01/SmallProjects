//stub class
public class LogicalSentence {

}
