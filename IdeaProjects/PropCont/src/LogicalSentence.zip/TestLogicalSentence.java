public class TestLogicalSentence {
    public static void main(String[] args){
        LogicalSentence l = new LogicalSentence();
        String[] testCases = {"a<=>b","a&b|c","a<=>&c","&a~c"};

        for(int i = 0;i<testCases.length;i++){
            System.out.println(testCases[i] + " is " + l.checkLegalSentence(testCases[i]));
        }
    }
}
