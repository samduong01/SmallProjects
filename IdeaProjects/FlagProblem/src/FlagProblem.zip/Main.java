import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        //create instance of FlagFrame class
        FlagFrame f = new FlagFrame();

        f.setDefaultCloseOperation(FlagFrame.EXIT_ON_CLOSE);
        f.setVisible(true);
    }
}
