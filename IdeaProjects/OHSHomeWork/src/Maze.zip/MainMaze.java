public class MainMaze {
    public static void main(String[] args){
        Maze maze = new Maze(15,15);
        maze.print();
    }
}
